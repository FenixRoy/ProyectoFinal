import Login from "../components/Login"





const IniciarSesion = () => {

    return(
        <Login></Login>
    )
}

export default IniciarSesion